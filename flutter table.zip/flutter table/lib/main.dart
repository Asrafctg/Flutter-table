import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'darasrc.dart';

void main() {
  runApp(MaterialApp(
    home: TablePage(),
  ));
}
class TablePage extends StatefulWidget{
  _State createState()=> _State();
}

class _State extends State<TablePage> {

  @override
  void initState(){
    fetchUser();
    super.initState();
  }

  List mylist =[];
  Future fetchUser() async{
   var response = await http.get(Uri.parse("https://jsonplaceholder.typicode.com/users"));
   var mydata = jsonDecode(response.body);
   if(response.statusCode ==200){
     setState(() {
       mylist = mydata;
       print(mylist.length);
     });
   }
   else{
     print('getting error');
   }
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text('Table Ex'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Column(
            children: [
              Text('Student Results'),
              Container(
                height: 500,
                child: ListView.builder(
                  itemCount: mylist.length,
                  itemBuilder: (context,index){
                    return Table(
                      border: TableBorder.all(width: 1,color: Colors.green),
                      children: [
                        TableRow(
                          children: [
                            TableCell(
                              child: Text(mylist[index]['id'].toString()),
                            ),
                            TableCell(
                              child: Text(mylist[index]['name'].toString()),
                            ),
                            TableCell(
                              child: Text(mylist[index]['username'].toString()),
                            ),
                            TableCell(
                              child: Text(mylist[index]['email'].toString()),
                            ),

                          ]
                        )
                      ],
                    );
                  },
                ),
              )
            ],
          ),
        ),
      )
    );
  }
}

/*
body: Padding(
padding: EdgeInsets.all(10),
child: Table(
border: TableBorder.all(color: Colors.red,width: 1),
children: [
TableRow(
children: [
TableCell(
child: Text('ID: 1'),
),
TableCell(
child: Center(child: Text('Basar'),)
),
TableCell(
child: Text('012ie912u0r97'),
),
]
),
TableRow(
children: [
TableCell(
child: Text('ID: 1'),
),
TableCell(
child: Text('Basar'),
),
TableCell(
child: Text('012ie912u0r97'),
),
]
),
TableRow(
children: [
TableCell(
child: Text('ID: 1'),
),
TableCell(
child: Center(child: Text('Basar'),)
),
TableCell(
child: Text('012ie912u0r97'),
),
]
),
TableRow(
children: [
TableCell(
child: Text('ID: 1'),
),
TableCell(
child: Text('Basar'),
),
TableCell(
child: Text('012ie912u0r97'),
),
]
),
],
),
),*/
